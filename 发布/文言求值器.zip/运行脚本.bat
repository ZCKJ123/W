@echo off
chcp 65001 >nul
setlocal
if "%~1"=="" (
  echo 请把 .脚本 文件拖到 文言求值器.exe 或 运行脚本.bat 上。
  pause
  exit /b 1
)
start /wait "" "%~dp0文言求值器.exe" "%~1"
if exist "%~1.out.txt" (
  type "%~1.out.txt"
  echo.
  echo 结果已保存：%~1.out.txt
) else (
  echo 没有产生输出文件
)
echo.
pause