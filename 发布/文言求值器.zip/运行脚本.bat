@echo off
chcp 65001 >nul
setlocal
if "%~1"=="" (
  echo 请把 .脚本 文件拖到 运行脚本.bat 上，或执行：运行脚本.bat 脚本.脚本
  pause
  exit /b 1
)
if not exist "C:\Temp" mkdir "C:\Temp" >nul 2>nul
copy /y "%~1" "C:\Temp\eval1.wen" >nul
del "C:\Temp\wen_out.txt" >nul 2>nul
start /wait "" "%~dp0文言求值器.exe"
if exist "C:\Temp\wen_out.txt" (
  type "C:\Temp\wen_out.txt"
) else (
  echo 没有产生输出文件 C:\Temp\wen_out.txt
)
echo.
pause